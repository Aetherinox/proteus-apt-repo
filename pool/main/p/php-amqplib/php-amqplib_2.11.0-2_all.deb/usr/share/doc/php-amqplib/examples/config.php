<?php

require_once 'PhpAmqpLib/autoload.php';

putenv('TEST_AMQP_DEBUG=1');
require_once __DIR__ . '/../tests/config.php';
