<?php

namespace Embed\Providers\OEmbed;

class Poll extends Polldaddy
{
    protected static $pattern = 'poll.fm/*';
}
