#!/bin/bash
/usr/lib/x86_64-linux-gnu/clevis-luks-askpass
