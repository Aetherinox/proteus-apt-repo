<?php
declare(strict_types = 1);

namespace BaconQrCode\Exception;

final class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
