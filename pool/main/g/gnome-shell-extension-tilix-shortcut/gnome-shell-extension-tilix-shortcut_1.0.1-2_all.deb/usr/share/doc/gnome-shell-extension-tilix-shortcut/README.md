# Launch Tilix (or Terminix) 

A GNOME Shell extension to open [Tilix](https://github.com/gnunn1/tilix) with a keyboard shortcut (Ctrl+Alt+T by default).

> Note that Terminix is changing it's name to Tilix due to a trademark issue with the Terminix International Corporation. This extension will launch Terminix if Tilix can not be found.

## Installation

###  From Gnome Shell Extensions Page

* gnome-shell-extensions-site: pending

### From Debian package

* Debian: Pending
* Ubuntu: Pending
* Mint: Pending

### From Source

Download from git:

```
$ git clone https://git.bluemosh.com/bluemosh/gse-tilix-shortcut
$ mv TilixKeyboardShortcut@jonathan.bluemosh.com $HOME/.local/share/gnome-shell/extensions/TilixKeyboardShortcut@jonathan.bluemosh.com
```

restart GNOME Shell (`Alt+F2 r Enter`) and enable the extension through gnome-tweak-tool.

## Configuring

### Custom hotkey

You can change the keyboard shortcut key via extension settings from gnome-tweak-tool.

## Note

Make sure you have either tilix or terminix installed!
